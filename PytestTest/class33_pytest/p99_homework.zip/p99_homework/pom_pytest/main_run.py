#!/usr/bin/env python
# -*- coding: utf-8 -*-
import pytest

if __name__ == '__main__':
    pytest.main(['-s'])